const data =[
  {
    text:"Write my first blog",
    date:"Nov 09 2021",
    category:{
      tag:"midium",
      color:"red"
    },
    link:{
      url:"",
      text:"read more"
    }
  },
  {
    text:"Write my first blog",
    date:"Nov 09 2021",
    category:{
      tag:"midium",
      color:"green"
    },
    link:{
      url:"",
      text:"read more"
    }
  },
  {
    text:"Write my first blog",
    date:"Nov 09 2021",
    category:{
      tag:"midium",
      color:"purple"
    },
    link:{
      url:"",
      text:"read more"
    }
  }
]

export default data;